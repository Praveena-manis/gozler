const greet=(name,greeting='Hello')=>console.log(`${greeting} ${name}`);

greet('Sonam','Good Morning..!');
greet('Nilu');