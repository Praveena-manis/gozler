const fname="sonam";
const mname="Nikunj";
const lname= "soni";

//Concatation
console.log('Full Name: '+fname+' '+mname+ ' ' + lname + '.');

//template Literal (Latest Syntax ES6)
console.log(`Full Name: ${fname} ${mname} ${lname}`);

const message=
            ` 
                Helllo.........
                How Are you...
                Testing
             `
             //Writing in `` called template literal
            //variable wrapping using ${} called interpolation

console.log(message);


