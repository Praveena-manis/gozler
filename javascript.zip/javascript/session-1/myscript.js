console.log("External Script included successfully")
alert("Script loaded")
document.write("<h2>Hello World</h2>")